# Authenticity Validator for Academia (AVFA) - Frontend & Backend Suite

## 🚀 How to Run Locally

1. Install requirements:
   ```bash
   pip install fastapi uvicorn python-multipart cryptography sqlalchemy
   ```

2. Run the application:
   ```bash
   uvicorn src.main:app --reload --port 8000
   ```

3. Open your browser:
   http://localhost:8000

## 📁 Key Frontend & Backend Structure
- `static/index.html` - Single Page Application UI with all views & modals
- `static/css/style.css` - Custom styling with design tokens & responsive grids
- `static/js/app.js` - Client-side state, API calls, QR generation & pipeline animations
- `src/` - FastAPI backend with RSA signing, SHA-256 verification, and SQLite/PostgreSQL fallback
