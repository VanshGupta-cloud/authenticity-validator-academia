import re
import secrets
import uuid
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from src.database import get_db
from src.models import Institution
from src.schemas import (
    InstitutionRegisterRequest, InstitutionLoginRequest, InstitutionLoginResponse
)
from src.security import hash_password, verify_password, create_access_token

router = APIRouter(
    prefix="/institutions",
    tags=["institutions"]
)

@router.post("/register", status_code=201)
def register_institution(
    payload: InstitutionRegisterRequest,
    db: Session = Depends(get_db)
):
    email_clean = payload.email.lower().strip()
    existing = db.query(Institution).filter(Institution.email == email_clean).first()
    if existing:
        raise HTTPException(status_code=409, detail="Institution already registered with this email")

    code = payload.code or "GIT"
    new_inst = Institution(
        id=str(uuid.uuid4()),
        name=payload.name.strip(),
        code=code.upper().strip(),
        email=email_clean,
        password_hash=hash_password(payload.password) if payload.password else hash_password("admin123"),
        is_verified=True,
        created_at=datetime.utcnow()
    )
    db.add(new_inst)
    db.commit()
    db.refresh(new_inst)

    return {
        "id": new_inst.id,
        "name": new_inst.name,
        "code": new_inst.code,
        "email": new_inst.email,
        "is_verified": new_inst.is_verified,
    }


@router.post("/login", response_model=InstitutionLoginResponse)
def login_institution(payload: InstitutionLoginRequest, db: Session = Depends(get_db)):
    email_clean = payload.email.lower().strip()
    inst = db.query(Institution).filter(Institution.email == email_clean).first()

    if not inst or not inst.password_hash:
        raise HTTPException(status_code=401, detail="Invalid institutional credentials")
    if not verify_password(payload.password, inst.password_hash):
        raise HTTPException(status_code=401, detail="Invalid institutional credentials")

    token = create_access_token({
        "sub": str(inst.id),
        "institution_id": str(inst.id),
        "role": "ISSUER",
        "name": inst.name,
        "email": inst.email
    })

    return {
        "access_token": token,
        "token_type": "bearer",
        "institution_id": str(inst.id),
        "name": inst.name,
        "email": inst.email
    }


@router.get("/")
def list_institutions(db: Session = Depends(get_db)):
    institutions = db.query(Institution).all()
    return institutions