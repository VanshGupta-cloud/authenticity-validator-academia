/**
 * Authenticity Validator for Academia (AVFA) - Frontend Application
 * Covers Verification, OCR RapidFuzz Comparison, Blockchain Explorer,
 * Issuance Pipeline, Student Wallet & Batch CSV processing.
 */

// Global State
const state = {
  user: null,
  token: localStorage.getItem('avfa_token') || null,
  currentView: 'home-view',
  certificates: [],
  selectedCertificate: null,
  activeVerifyTab: 'file',
  stats: {
    certificates_issued: 128,
    active: 124,
    revoked: 4,
    verification_checks: 342
  }
};

// API Service Layer
const API = {
  baseUrl: '',

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const headers = options.headers || {};

    if (state.token) {
      headers['Authorization'] = `Bearer ${state.token}`;
    }

    if (!(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    try {
      const response = await fetch(url, { ...options, headers });
      const data = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error((data && (data.detail || data.message)) || `Request failed (${response.status})`);
      }

      return data;
    } catch (err) {
      console.error(`API Error on ${endpoint}:`, err);
      throw err;
    }
  },

  async login(email, password) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
  },

  async register(full_name, email, password, role = 'STUDENT') {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ full_name, email, password, role })
    });
  },

  async getStats() {
    return this.request('/certificates/stats');
  },

  async getCertificates(search = '', status_filter = '') {
    let query = '?';
    if (search) query += `search=${encodeURIComponent(search)}&`;
    if (status_filter) query += `status_filter=${encodeURIComponent(status_filter)}`;
    return this.request(`/certificates/${query}`);
  },

  async getCertificateById(id) {
    return this.request(`/certificates/${id}`);
  },

  async verifyCertificate(payload) {
    return this.request('/certificates/verify', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async verifyCertificateFile(formData) {
    return this.request('/certificates/verify', {
      method: 'POST',
      body: formData
    });
  },

  async issueCertificate(certData) {
    return this.request('/certificates/issue', {
      method: 'POST',
      body: JSON.stringify(certData)
    });
  },

  async revokeCertificate(id, reason) {
    return this.request(`/certificates/${id}/revoke`, {
      method: 'PATCH',
      body: JSON.stringify({ revocation_reason: reason })
    });
  },

  async getBlockchainLedger() {
    return this.request('/certificates/blockchain-ledger');
  },

  async compareOcr(payload) {
    return this.request('/certificates/ocr-compare', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async batchIssue(records) {
    return this.request('/certificates/batch-issue', {
      method: 'POST',
      body: JSON.stringify(records)
    });
  }
};

// Application Initialization
document.addEventListener('DOMContentLoaded', async () => {
  // Check stored session
  const storedUser = localStorage.getItem('avfa_user');
  if (storedUser && state.token) {
    try {
      state.user = JSON.parse(storedUser);
    } catch (e) {
      logout();
    }
  }

  updateAuthUI();
  setupEventListeners();

  // Load initial data
  try {
    await fetchAndRenderStats();
    await fetchAndRenderCertificates();
    await fetchAndRenderBlockchain();
  } catch (e) {
    console.warn('Initial data fetch notice:', e);
  }
});

// Setup Events
function setupEventListeners() {
  // File drag and drop
  const dropzone = document.getElementById('verifier-dropzone');
  const fileInput = document.getElementById('verifier-file-input');

  if (dropzone && fileInput) {
    dropzone.addEventListener('click', () => fileInput.click());

    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = 'var(--color-accent-hover)';
    });

    dropzone.addEventListener('dragleave', () => {
      dropzone.style.borderColor = 'var(--color-accent)';
    });

    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = 'var(--color-accent)';
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFileVerify(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files[0]) {
        handleFileVerify(e.target.files[0]);
      }
    });
  }

  // Hash form verification
  const hashForm = document.getElementById('verify-hash-form');
  if (hashForm) {
    hashForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('verify-hash-input').value.trim();
      if (!input) return;

      if (input.startsWith('0x') || input.length >= 32) {
        performVerification({ queried_hash: input });
      } else {
        performVerification({ certificate_number: input });
      }
    });
  }

  // Search input in dashboard table
  const searchInput = document.getElementById('table-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', debounce((e) => {
      const status = document.getElementById('table-status-filter').value;
      fetchAndRenderCertificates(e.target.value, status);
    }, 300));
  }

  const statusFilter = document.getElementById('table-status-filter');
  if (statusFilter) {
    statusFilter.addEventListener('change', (e) => {
      const search = document.getElementById('table-search-input').value;
      fetchAndRenderCertificates(search, e.target.value);
    });
  }

  // Issue Certificate Form
  const issueForm = document.getElementById('issue-certificate-form');
  if (issueForm) {
    issueForm.addEventListener('submit', handleIssueCertificate);
  }
}

// Navigation Router
function navigateTo(viewId) {
  state.currentView = viewId;

  document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
  const target = document.getElementById(viewId);
  if (target) {
    target.classList.add('active');
  }

  document.querySelectorAll('.nav-link').forEach(link => {
    if (link.getAttribute('data-view') === viewId) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  window.scrollTo({ top: 0, behavior: 'smooth' });

  if (viewId === 'issuer-dashboard-view') {
    fetchAndRenderStats();
    fetchAndRenderCertificates();
  } else if (viewId === 'blockchain-view') {
    fetchAndRenderBlockchain();
  } else if (viewId === 'student-wallet-view') {
    renderStudentWallet();
  }
}

// Auth State UI Update
function updateAuthUI() {
  const authButtons = document.getElementById('nav-auth-buttons');
  const userMenu = document.getElementById('nav-user-menu');
  const userName = document.getElementById('nav-user-name');
  const userRole = document.getElementById('nav-user-role');
  const userAvatar = document.getElementById('nav-user-avatar');

  if (state.user && state.token) {
    if (authButtons) authButtons.style.display = 'none';
    if (userMenu) userMenu.style.display = 'flex';
    if (userName) userName.textContent = state.user.full_name || 'User';
    if (userRole) userRole.textContent = state.user.role || 'ISSUER';
    if (userAvatar) userAvatar.textContent = (state.user.full_name || 'U').charAt(0).toUpperCase();
  } else {
    if (authButtons) authButtons.style.display = 'flex';
    if (userMenu) userMenu.style.display = 'none';
  }
}

function logout() {
  state.user = null;
  state.token = null;
  localStorage.removeItem('avfa_token');
  localStorage.removeItem('avfa_user');
  updateAuthUI();
  showToast('Logged out successfully', 'info');
  navigateTo('home-view');
}

// Stats Fetch & Render
async function fetchAndRenderStats() {
  try {
    const data = await API.getStats();
    state.stats = data;

    const elIssued = document.getElementById('stat-issued');
    const elActive = document.getElementById('stat-active');
    const elRevoked = document.getElementById('stat-revoked');
    const elChecks = document.getElementById('stat-checks');

    if (elIssued) elIssued.textContent = data.certificates_issued;
    if (elActive) elActive.textContent = data.active;
    if (elRevoked) elRevoked.textContent = data.revoked;
    if (elChecks) elChecks.textContent = data.verification_checks;
  } catch (err) {
    console.error('Failed to fetch stats:', err);
  }
}

// Certificates Fetch & Render
async function fetchAndRenderCertificates(search = '', status = '') {
  const tbody = document.getElementById('certificates-table-body');
  if (!tbody) return;

  tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--color-text-muted);">Loading verified records...</td></tr>`;

  try {
    const certs = await API.getCertificates(search, status);
    state.certificates = certs;

    if (certs.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--color-text-muted); padding: 2rem;">No matching credentials found.</td></tr>`;
      return;
    }

    tbody.innerHTML = certs.map(c => `
      <tr>
        <td style="font-family: var(--font-mono); font-weight: 700; color: var(--color-primary);">${c.certificate_number}</td>
        <td style="font-weight: 600;">${c.student_name}</td>
        <td>${c.course_name}</td>
        <td style="font-weight: 600;">${c.cgpa || '9.8 / 10.0'}</td>
        <td style="color: var(--color-text-muted); font-size: 0.85rem;">${c.issue_date}</td>
        <td>
          <span class="status-pill ${c.status === 'ISSUED' ? 'valid' : 'revoked'}">
            ${c.status === 'ISSUED' ? 'Active' : 'Revoked'}
          </span>
        </td>
        <td>
          <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-secondary btn-sm" onclick="viewCertificateDetails('${c.id}')">View</button>
            ${c.status === 'ISSUED' ? `<button class="btn btn-secondary btn-sm" style="color: var(--color-danger); border-color: #FECACA;" onclick="openRevokeModal('${c.id}', '${c.certificate_number}')">Revoke</button>` : ''}
          </div>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--color-danger);">Failed to load certificates.</td></tr>`;
  }
}

// Blockchain Ledger Fetch & Render
async function fetchAndRenderBlockchain() {
  const blocksContainer = document.getElementById('blocks-container');
  const txBody = document.getElementById('blockchain-tx-body');

  try {
    const data = await API.getBlockchainLedger();
    if (blocksContainer && data.blocks) {
      blocksContainer.innerHTML = data.blocks.map(b => `
        <div class="block-card">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span class="block-height">Block #${b.block_number}</span>
            <span class="status-pill valid" style="font-size: 0.7rem;">CONFIRMED</span>
          </div>
          <div>
            <div style="font-size: 0.72rem; color: var(--color-text-light); text-transform: uppercase; font-weight: 600;">Block Hash</div>
            <div class="block-hash-text">${b.block_hash.substring(0, 24)}...</div>
          </div>
          <div>
            <div style="font-size: 0.72rem; color: var(--color-text-light); text-transform: uppercase; font-weight: 600;">Merkle Root</div>
            <div class="block-hash-text">${b.merkle_root.substring(0, 24)}...</div>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--color-text-muted); border-top: 1px dashed var(--color-card-border); padding-top: 0.5rem; margin-top: 0.25rem;">
            <span>Transactions: <strong>${b.tx_count}</strong></span>
            <span>Gas: <strong>${b.gas_used}</strong></span>
          </div>
        </div>
      `).join('');
    }

    if (txBody && data.recent_transactions) {
      txBody.innerHTML = data.recent_transactions.map(t => `
        <tr>
          <td style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--color-accent);">${t.tx_hash}</td>
          <td style="font-family: var(--font-mono); font-weight: 600;">${t.certificate_number}</td>
          <td>${t.student_name}</td>
          <td><span class="status-pill ${t.action === 'ENROLL_CREDENTIAL' ? 'valid' : 'revoked'}" style="font-size: 0.75rem;">${t.action}</span></td>
          <td style="font-family: var(--font-mono);">#${t.block_number}</td>
          <td><span class="status-pill valid" style="font-size: 0.75rem;">● ${t.status}</span></td>
        </tr>
      `).join('');
    }
  } catch (err) {
    console.error('Blockchain fetch error:', err);
  }
}

// Student Wallet Render
function renderStudentWallet() {
  const container = document.getElementById('student-wallet-grid');
  if (!container) return;

  const sampleDegrees = [
    {
      title: "Master of Science in Computer Science",
      inst: "Global Institute of Technology",
      student: state.user ? state.user.full_name : "Elena R. Vance",
      roll: "CS-2024-001",
      cgpa: "9.82 / 10.0",
      date: "October 24, 2024",
      hash: "0x7a34f89b2c8e19a4d0f872b1cd12c9e4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0"
    }
  ];

  container.innerHTML = sampleDegrees.map(d => `
    <div class="data-card" style="border-top: 4px solid var(--color-accent);">
      <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
        <div>
          <span style="font-size: 0.75rem; color: var(--color-accent); font-weight: 700; text-transform: uppercase;">Official Degree Credential</span>
          <h3 style="font-family: var(--font-heading); font-size: 1.25rem; font-weight: 700; color: var(--color-primary); margin-top: 0.2rem;">${d.title}</h3>
          <div style="font-size: 0.85rem; color: var(--color-text-muted);">${d.inst}</div>
        </div>
        <span class="status-pill valid">VERIFIED</span>
      </div>

      <div style="background: var(--color-bg); padding: 1rem; border-radius: var(--radius-md); font-size: 0.85rem; margin-bottom: 1.25rem;">
        <div>Recipient: <strong>${d.student}</strong></div>
        <div>Roll Number: <strong>${d.roll}</strong></div>
        <div>CGPA: <strong>${d.cgpa}</strong></div>
        <div>Award Date: <strong>${d.date}</strong></div>
      </div>

      <div style="display: flex; gap: 0.5rem;">
        <button class="btn btn-primary btn-sm btn-block" onclick="openVerificationModal('file')">Verify Badge</button>
        <button class="btn btn-secondary btn-sm" onclick="showToast('Shareable verification link copied!', 'success')">Share</button>
      </div>
    </div>
  `).join('');
}

// Verification Modal & Tabs
function openVerificationModal(tab = 'file') {
  const modal = document.getElementById('verifier-modal');
  if (modal) {
    modal.classList.add('open');
    switchVerifyTab(tab);
  }
}

function closeVerificationModal() {
  const modal = document.getElementById('verifier-modal');
  if (modal) modal.classList.remove('open');
}

function switchVerifyTab(tabName) {
  state.activeVerifyTab = tabName;

  document.querySelectorAll('.verify-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
  });

  document.querySelectorAll('.verify-tab-content').forEach(c => c.style.display = 'none');
  const activeTabContent = document.getElementById(`tab-content-${tabName}`);
  if (activeTabContent) activeTabContent.style.display = 'block';
}

// Verification Handlers
async function handleFileVerify(file) {
  const resultBox = document.getElementById('verify-result-box');
  resultBox.style.display = 'block';
  resultBox.innerHTML = `
    <div style="text-align: center; padding: 1.5rem; color: var(--color-text-muted);">
      <div>Computing SHA-256 binary hash and running cryptographic signature check...</div>
    </div>
  `;

  const formData = new FormData();
  formData.append('file', file);

  try {
    const res = await API.verifyCertificateFile(formData);
    renderVerificationResult(res);
  } catch (err) {
    // If file hash not found in DB, run client hash calculation
    try {
      const buffer = await file.arrayBuffer();
      const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      
      const res = await API.verifyCertificate({ queried_hash: hashHex });
      renderVerificationResult(res);
    } catch (e2) {
      renderVerificationResult({
        verification_status: 'NOT_FOUND',
        message: 'No registered academic credential matches the uploaded document.'
      });
    }
  }
}

async function performVerification(payload) {
  const resultBox = document.getElementById('verify-result-box');
  resultBox.style.display = 'block';
  resultBox.innerHTML = `
    <div style="text-align: center; padding: 1.5rem; color: var(--color-text-muted);">
      <div>Querying decentralized database and checking RSA-2048 signature...</div>
    </div>
  `;

  try {
    const res = await API.verifyCertificate(payload);
    renderVerificationResult(res);
  } catch (err) {
    renderVerificationResult({
      verification_status: 'NOT_FOUND',
      message: err.message || 'Verification failed.'
    });
  }
}

function renderVerificationResult(res) {
  const resultBox = document.getElementById('verify-result-box');
  if (!resultBox) return;

  const status = res.verification_status || 'NOT_FOUND';
  const cert = res.certificate;
  const checks = res.checks || { hash_match: false, signature_valid: false, tamper_detected: true, ledger_anchored: false };

  let statusHtml = '';
  if (status === 'VALID') {
    statusHtml = `<span class="status-pill valid" style="font-size: 1rem; padding: 0.5rem 1rem;">VERIFIED & AUTHENTIC</span>`;
  } else if (status === 'REVOKED') {
    statusHtml = `<span class="status-pill revoked" style="font-size: 1rem; padding: 0.5rem 1rem;">REVOKED CREDENTIAL</span>`;
  } else if (status === 'TAMPERED') {
    statusHtml = `<span class="status-pill tampered" style="font-size: 1rem; padding: 0.5rem 1rem;">TAMPER DETECTED / INVALID</span>`;
  } else {
    statusHtml = `<span class="status-pill not-found" style="font-size: 1rem; padding: 0.5rem 1rem;">NOT FOUND IN REGISTRY</span>`;
  }

  resultBox.innerHTML = `
    <div class="data-card" style="border: 1px solid var(--color-card-border); margin-top: 1rem;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; border-bottom: 1px solid var(--color-card-border); padding-bottom: 0.75rem;">
        <span style="font-weight: 700; font-size: 0.95rem;">Cryptographic Audit Result</span>
        ${statusHtml}
      </div>

      <div style="font-size: 0.88rem; color: var(--color-text-main); margin-bottom: 1.25rem; line-height: 1.5;">
        ${res.message || 'Audit check completed.'}
      </div>

      ${cert ? `
        <div style="background: var(--color-bg); padding: 1rem; border-radius: var(--radius-md); font-size: 0.88rem; margin-bottom: 1.25rem; display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
          <div><span style="color: var(--color-text-muted);">Student Name:</span> <strong>${cert.student_name}</strong></div>
          <div><span style="color: var(--color-text-muted);">Roll Number:</span> <strong>${cert.student_roll_no}</strong></div>
          <div><span style="color: var(--color-text-muted);">Degree Program:</span> <strong>${cert.degree_name}</strong></div>
          <div><span style="color: var(--color-text-muted);">Issue Date:</span> <strong>${cert.issue_date}</strong></div>
          <div><span style="color: var(--color-text-muted);">Institution:</span> <strong>${cert.institution_name}</strong></div>
          <div><span style="color: var(--color-text-muted);">CGPA:</span> <strong>${cert.cgpa || '9.8 / 10.0'}</strong></div>
        </div>
      ` : ''}

      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; font-size: 0.82rem;">
        <div style="display: flex; gap: 0.4rem; align-items: center;">${checks.hash_match ? '✅' : '❌'} SHA-256 Hash Match</div>
        <div style="display: flex; gap: 0.4rem; align-items: center;">${checks.signature_valid ? '✅' : '❌'} RSA-2048 Signature</div>
        <div style="display: flex; gap: 0.4rem; align-items: center;">${!checks.tamper_detected ? '✅' : '❌'} Zero Tampering</div>
        <div style="display: flex; gap: 0.4rem; align-items: center;">${checks.ledger_anchored ? '✅' : '❌'} Immutable Ledger Anchor</div>
      </div>
    </div>
  `;
}

// OCR Analysis Demo (RapidFuzz pipeline)
async function runOcrAnalysisDemo() {
  const resultsArea = document.getElementById('ocr-results-area');
  resultsArea.style.display = 'block';

  try {
    const res = await API.compareOcr({
      certificate_number: 'AVFA-GIT-2024-001',
      extracted_fields: {
        student_name: 'Elena R. Vance',
        student_roll_no: 'CS-2024-001',
        degree_name: 'Master of Science in Computer Science',
        issue_date: '2024-10-24',
        institution: 'Global Institute of Technology'
      }
    });

    document.getElementById('ocr-status-pill').textContent = `${res.status} (${res.overall_similarity}%)`;
    document.getElementById('ocr-status-pill').className = `status-pill ${res.status === 'VERIFIED' ? 'valid' : 'revoked'}`;
    
    document.getElementById('ocr-score-name').textContent = `${res.field_scores.student_name}%`;
    document.getElementById('ocr-bar-name').style.width = `${res.field_scores.student_name}%`;

    document.getElementById('ocr-score-roll').textContent = `${res.field_scores.student_roll_no}%`;
    document.getElementById('ocr-bar-roll').style.width = `${res.field_scores.student_roll_no}%`;

    document.getElementById('ocr-score-degree').textContent = `${res.field_scores.degree_name}%`;
    document.getElementById('ocr-bar-degree').style.width = `${res.field_scores.degree_name}%`;

    document.getElementById('ocr-score-date').textContent = `${res.field_scores.issue_date}%`;
    document.getElementById('ocr-bar-date').style.width = `${res.field_scores.issue_date}%`;

    document.getElementById('ocr-score-inst').textContent = `${res.field_scores.institution}%`;
    document.getElementById('ocr-bar-inst').style.width = `${res.field_scores.institution}%`;

    showToast('OCR extracted & RapidFuzz similarity calculated!', 'success');
  } catch (err) {
    showToast('OCR pipeline error', 'error');
  }
}

// Batch Upload Modal & Processing
function openBatchUploadModal() {
  const modal = document.getElementById('batch-modal');
  if (modal) modal.classList.add('open');
}

function closeBatchUploadModal() {
  const modal = document.getElementById('batch-modal');
  if (modal) modal.classList.remove('open');
}

async function simulateBatchUpload() {
  const progressBar = document.getElementById('batch-progress');
  const bar = document.getElementById('batch-bar');
  progressBar.style.display = 'block';

  const sampleRecords = [
    { student_name: "Liam O'Connor", student_roll_no: "CS-2026-101", course_name: "B.Tech in Artificial Intelligence", issue_date: "2026-08-16", cgpa: "9.4 / 10.0" },
    { student_name: "Aria Montgomery", student_roll_no: "CS-2026-102", course_name: "B.Tech in Cyber Security", issue_date: "2026-08-16", cgpa: "9.7 / 10.0" },
    { student_name: "Devin Zhao", student_roll_no: "CS-2026-103", course_name: "Master of Science in Data Science", issue_date: "2026-08-16", cgpa: "9.2 / 10.0" },
    { student_name: "Priya Sharma", student_roll_no: "CS-2026-104", course_name: "Ph.D in Cryptographic Protocols", issue_date: "2026-08-16", cgpa: "9.9 / 10.0" },
    { student_name: "Mateo Alvarez", student_roll_no: "CS-2026-105", course_name: "B.Tech in Information Technology", issue_date: "2026-08-16", cgpa: "8.9 / 10.0" }
  ];

  bar.style.width = '30%';
  setTimeout(async () => {
    bar.style.width = '75%';
    try {
      const res = await API.batchIssue(sampleRecords);
      bar.style.width = '100%';
      setTimeout(() => {
        showToast(res.message || 'Batch processed successfully!', 'success');
        closeBatchUploadModal();
        fetchAndRenderStats();
        fetchAndRenderCertificates();
      }, 500);
    } catch (e) {
      showToast('Batch processing failed', 'error');
    }
  }, 800);
}

// Issue Certificate with Animated Pipeline
async function handleIssueCertificate(e) {
  e.preventDefault();

  const studentName = document.getElementById('issue-student-name').value.trim();
  const rollNo = document.getElementById('issue-student-roll').value.trim();
  const degree = document.getElementById('issue-degree').value;
  const cgpa = document.getElementById('issue-cgpa').value.trim();
  const issueDate = document.getElementById('issue-date').value;

  const pipelineModal = document.getElementById('pipeline-modal');
  pipelineModal.classList.add('open');

  const steps = ['step-validate', 'step-hash', 'step-sign', 'step-qr', 'step-pdf', 'step-enroll'];
  steps.forEach(s => {
    const el = document.getElementById(s);
    if (el) el.className = 'pipeline-step-item';
  });

  const runStep = (idx) => {
    if (idx < steps.length) {
      const el = document.getElementById(steps[idx]);
      if (el) el.classList.add('active');
      setTimeout(() => {
        if (el) {
          el.classList.remove('active');
          el.classList.add('done');
        }
        runStep(idx + 1);
      }, 400);
    }
  };

  runStep(0);

  try {
    const newCert = await API.issueCertificate({
      student_name: studentName,
      student_roll_no: rollNo,
      course_name: degree,
      cgpa: cgpa,
      issue_date: issueDate
    });

    setTimeout(() => {
      pipelineModal.classList.remove('open');
      showToast('Certificate cryptographically signed & anchored!', 'success');
      viewCertificateDetails(newCert.id, newCert);
    }, 2800);
  } catch (err) {
    pipelineModal.classList.remove('open');
    showToast(`Issuance failed: ${err.message}`, 'error');
  }
}

// View Certificate Detail Screen
async function viewCertificateDetails(id, certData = null) {
  let cert = certData;
  if (!cert) {
    try {
      cert = await API.getCertificateById(id);
    } catch (err) {
      showToast('Failed to load certificate details', 'error');
      return;
    }
  }

  state.selectedCertificate = cert;

  document.getElementById('view-cert-student').textContent = cert.student_name;
  document.getElementById('view-cert-roll').textContent = cert.student_roll_no;
  document.getElementById('view-cert-degree').textContent = cert.course_name;
  document.getElementById('view-cert-cgpa').textContent = cert.cgpa || '9.8 / 10.0';
  document.getElementById('view-cert-date').textContent = cert.issue_date;
  document.getElementById('view-cert-id').textContent = cert.certificate_number;
  document.getElementById('view-sidebar-num').textContent = cert.certificate_number;
  document.getElementById('view-sidebar-hash').textContent = `${(cert.sha256_hash || '').substring(0, 16)}...`;

  const statusEl = document.getElementById('view-sidebar-status');
  if (cert.status === 'ISSUED') {
    statusEl.innerHTML = `<span class="status-pill valid">VALID & ACTIVE</span>`;
  } else {
    statusEl.innerHTML = `<span class="status-pill revoked">REVOKED</span>`;
  }

  const qrImg = document.getElementById('view-cert-qr');
  const verifyUrl = `${window.location.origin}/?verify=${cert.certificate_number}`;
  qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(verifyUrl)}`;

  const revokeBtn = document.getElementById('view-sidebar-revoke-btn');
  if (revokeBtn) {
    if (cert.status === 'ISSUED') {
      revokeBtn.style.display = 'block';
      revokeBtn.onclick = () => openRevokeModal(cert.id, cert.certificate_number);
    } else {
      revokeBtn.style.display = 'none';
    }
  }

  navigateTo('certificate-detail-view');
}

// PDF Download
function downloadCertificatePDF() {
  window.print();
}

// Revocation Modal
let targetRevokeId = null;
function openRevokeModal(id, certNum) {
  targetRevokeId = id;
  const numEl = document.getElementById('revoke-cert-num');
  if (numEl) numEl.textContent = certNum;
  const modal = document.getElementById('revoke-modal');
  if (modal) modal.classList.add('open');
}

function closeRevokeModal() {
  targetRevokeId = null;
  const modal = document.getElementById('revoke-modal');
  if (modal) modal.classList.remove('open');
}

async function confirmRevocation() {
  if (!targetRevokeId) return;
  const reason = document.getElementById('revoke-reason').value.trim();
  if (!reason) {
    showToast('Please specify a revocation reason', 'error');
    return;
  }

  try {
    await API.revokeCertificate(targetRevokeId, reason);
    showToast('Certificate successfully revoked', 'success');
    closeRevokeModal();
    fetchAndRenderStats();
    fetchAndRenderCertificates();
    if (state.currentView === 'certificate-detail-view') {
      viewCertificateDetails(targetRevokeId);
    }
  } catch (err) {
    showToast(`Revocation failed: ${err.message}`, 'error');
  }
}

// Toast Notifications
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span><span>${message}</span>`;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function copyText(text) {
  navigator.clipboard.writeText(text);
  showToast('Copied to clipboard!', 'success');
}

function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}
